#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <stdbool.h>
#include <time.h>
#include <math.h>

#define GENERADOR   0
#define VERIFICADOR 1

long total_puntos, lote;
const int RONDAS = 4;

double *buffer_x, *buffer_y;
long dentro_circulo = 0;

volatile bool flag[2] = {false, false};
volatile int  turno = GENERADOR;
volatile int  fase  = GENERADOR;

pthread_mutex_t mutex_datos = PTHREAD_MUTEX_INITIALIZER;

void entrar_region(int proceso) {
    int otro = 1 - proceso;
    flag[proceso] = true;
    while (flag[otro]) {
        if (turno != proceso) {
            flag[proceso] = false;
            while (turno != proceso) { }
            flag[proceso] = true;
        }
    }
}

void salir_region(int proceso) {
    turno = 1 - proceso;
    flag[proceso] = false;
}

void *hilo_generador(void *arg) {
    unsigned int semilla = (unsigned int)time(NULL) ^ (unsigned int)(size_t)pthread_self();

    for (int r = 0; r < RONDAS; r++) {
        entrar_region(GENERADOR);
        while (fase != GENERADOR) {
            salir_region(GENERADOR);
            entrar_region(GENERADOR);
        }

        printf("[Generador]   Ronda %d: generando %ld puntos...\n", r + 1, lote);

        pthread_mutex_lock(&mutex_datos);
        for (long i = 0; i < lote; i++) {
            buffer_x[i] = ((double)rand_r(&semilla) / RAND_MAX) * 2.0 - 1.0;
            buffer_y[i] = ((double)rand_r(&semilla) / RAND_MAX) * 2.0 - 1.0;
        }
        pthread_mutex_unlock(&mutex_datos);

        fase = VERIFICADOR;
        salir_region(GENERADOR);
    }
    return NULL;
}

void *hilo_verificador(void *arg) {
    for (int r = 0; r < RONDAS; r++) {
        entrar_region(VERIFICADOR);
        while (fase != VERIFICADOR) {
            salir_region(VERIFICADOR);
            entrar_region(VERIFICADOR);
        }

        printf("[Verificador] Ronda %d: aplicando teorema de Pitagoras...\n", r + 1);

        long contador = 0;
        pthread_mutex_lock(&mutex_datos);
        for (long i = 0; i < lote; i++) {
            double dist2 = buffer_x[i] * buffer_x[i] + buffer_y[i] * buffer_y[i];
            if (dist2 <= 1.0) contador++;
        }
        dentro_circulo += contador;
        pthread_mutex_unlock(&mutex_datos);

        fase = GENERADOR;
        salir_region(VERIFICADOR);
    }
    return NULL;
}

int main(void) {
    printf("Ingresa la cantidad total de puntos: ");
    if (scanf("%ld", &total_puntos) != 1 || total_puntos < 4) {
        printf("Ingresa un numero valido (>= 4).\n");
        return 1;
    }

    lote = total_puntos / 4;
    long puntos_reales = lote * 4;

    buffer_x = malloc(sizeof(double) * lote);
    buffer_y = malloc(sizeof(double) * lote);
    if (!buffer_x || !buffer_y) { perror("malloc"); return 1; }

    clock_t begin = clock();

    pthread_t t_gen, t_ver;
    pthread_create(&t_gen, NULL, hilo_generador, NULL);
    pthread_create(&t_ver, NULL, hilo_verificador, NULL);

    pthread_join(t_gen, NULL);
    pthread_join(t_ver, NULL);

    clock_t end = clock();
    double time = (double)(end - begin) / CLOCKS_PER_SEC;

    double pi_estimado = 4.0 * (double)dentro_circulo / (double)puntos_reales;

    printf("\nPuntos totales generados: %ld\n", puntos_reales);
    printf("Puntos dentro del circulo: %ld\n", dentro_circulo);
    printf("Valor estimado de Pi:      %f\n", pi_estimado);

    printf( "Tiempo en proceso:%f segundos  \n" ,time);

    pthread_mutex_destroy(&mutex_datos);
    free(buffer_x);
    free(buffer_y);
    return 0;
}