#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <pthread.h>
#include <unistd.h>
#include <stdbool.h>

#define N_ENTER 5
#define N_INCREMENTOS 200000
#define LIMITE_CORTESIAS 3000

int MODE = 0;

volatile bool flag [2] = {false,false};
volatile int turn = 0;

long shared_counter = 0;

volatile int adentro = 0;
volatile int violaciones = 0;

pthread_mutex_t mutexA = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutexB = PTHREAD_MUTEX_INITIALIZER;

void seccion_critica(int id) {
    adentro++;
    if (adentro > 1) {
        violaciones++;
        printf("VIOLACION EL PROCESO %d ENTRO ESTANDO OTRO YA ADENTRO" " Van %d vilaciones\n", id, violaciones);
    }

    for (int i = 0; i < N_INCREMENTOS; i++) {
        long tmp = shared_counter;
        tmp = tmp + 1;
        shared_counter = tmp;
    }

    printf("Proceso %d ENTRO a la seccion critica --> tiempo = %ld\n", id, shared_counter);
    adentro--;

}

void* dekker_m0(void* arg) {
    for (int k = 0; k < N_ENTER; k++) {
        flag[0] = true;
        while (flag[1]) {
            if (turn != 0) {
                flag[0] = false;
                while (turn != 0) { }
                flag[0] = true;
            }
        }
        seccion_critica(0);
        turn = 1;
        flag[0] = false;
        usleep(1000);
    }
    return NULL;
}

void* dekker_m1(void* arg) {
    for (int k = 0; k < N_ENTER; k++) {
        flag[1] = true;
        while (flag[0]) {
            if (turn != 1) {
                flag[1] = false;
                while (turn != 1) { }
                flag[1] = true;
            }
        }
        seccion_critica(1);
        turn = 0;
        flag[1] = false;
        usleep(1000);
    }
    return NULL;
}

void* sinlock_m0(void* arg) {
    for (int k = 0; k < N_ENTER; k++) {
        seccion_critica(0); usleep(1000);}
    return NULL;
}
void* sinlock_m1(void* arg) {
    for (int k = 0; k < N_ENTER; k++) {
        seccion_critica(1); usleep(1000);
    }
    return NULL;
}

void* deadlock_p0(void* arg) {
    pthread_mutex_lock(&mutexA);
    printf("Proceso 0 tomo mutex A....Esperando mutex B\n");
    usleep(200000);
    pthread_mutex_lock(&mutexB);
    seccion_critica(0);
    pthread_mutex_unlock(&mutexB);
    pthread_mutex_unlock(&mutexA);

    return NULL;
}

void* deadlock_p1(void* arg) {
    pthread_mutex_lock(&mutexB);
    printf("Proceso 1 tomo mutex B....Esperando mutex A\n");
    usleep(200000);
    pthread_mutex_lock(&mutexA);
    seccion_critica(1);
    pthread_mutex_unlock(&mutexA);
    pthread_mutex_unlock(&mutexB);

    return NULL;
}

void alarma_deadlock(int sig) {
    printf("\n El programa lleva varios segundos sin terminar" " Forzando cierre \n");
    exit(1);
}

void simular_livelock(void) {
    flag[0] = true;
    flag[1] = true;
    printf("Proceso 0 pide entrar\n");
    printf("Proceso 1 pide entrar\n\n");

    int ronda;
    for (ronda = 1; ronda <=6; ronda++) {
        printf("Ronda %d:\n", ronda);
        printf("Proceso 0 ve flag[1]=true y cede\n");
        printf("Proceso 1 ve flag[0]=true y cede\n");
        printf("entran en shock y vuelven a subir su bander al mismo tiempo\n");
        printf("Proceso 0 --> flag[0]=true \n");
        printf("Proceso 1 --> flag[1]=true \n");
        usleep(300000);

    }

    printf("%d-ronda Vuelven a entrar en shock 0 y 1 son estupidos jsjsjsjs", ronda - 1);

}

int main(int argc, char** argv) {
    if (argc > 1) MODE = atoi(argv[1]);
    setvbuf(stdout, NULL, _IONBF, 0);

    pthread_t t0, t1;
    void* (*f0)(void*) = NULL;
    void* (*f1)(void*) = NULL;

    switch (MODE) {
        case 0:
            printf("===MODO 0: Dekker funcional===\n");
            printf("Se espera: contador final = %d, 0 violaciones\n\n", N_ENTER * N_INCREMENTOS * 2);
            f0=dekker_m0; f1=dekker_m1;
            break;

        case 1:
            printf("===MODO 1: Sin Sincronizacion===\n");
            printf("Se espera ver violaciones y un contador final menor al esperado\n\n", N_ENTER * N_INCREMENTOS * 2);
            f0=sinlock_m0; f1=sinlock_m1;
            break;
        case 2:
            printf("===MODO 2: DEADLOCK===\n");
            printf("El programa se queda colgado\n\n");
            signal(SIGALRM, alarma_deadlock);
            alarm(4);
            f0=deadlock_p0; f1=deadlock_p1;
            break;
        case 3:
            printf("===MODO 3: LIVELOCK===\n");
            printf("Simulacion de lo que pasa sin TURN (ceden el paso)\n");
            simular_livelock();

            return 0;
            break;
        default:
            return 1;

    }

    pthread_create(&t0, NULL, f0, NULL);
    pthread_create(&t1, NULL, f1, NULL);
    pthread_join(t0, NULL);
    pthread_join(t1, NULL);

    printf("Contaddor compartido %ld\n", shared_counter);
    printf("Violaciones vistas %d\n", violaciones);
    return 0;
}